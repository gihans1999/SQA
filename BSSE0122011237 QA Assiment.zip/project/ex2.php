<!DOCTYPE html>
<html lang="en">
<head>
<style>

.npbutton{
  position: relative;
  top:1050px;
  left:20px;
}
          #next{
            border: none;
            color:white;
            background-color: #4CAF50;
            padding: 5px 10px 5px 10px;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
          }
          #next:hover{
            background-color: red;
          }
        </style>
        
        <style>
          #previous{
            border: none;
            color: white;
            background-color: #4CAF50;
            padding: 5px 10px 5px 10px;
            text-decoration: none;
            font-size: 18px;
            font-weight: bold;
          }
          #previous:hover{
            background-color: red;
          }
        </style>
<style>
        .canteinerdiv{
            position: relative;
            display: inline-block;
        }
        .canteinerlabel{
            
            position: relative;
            width:200px ;
            height:300px ;
            border: 3px solid orange;
            display: inline-block;
            margin: 20px;
        }
        .canteinerlabel:hover{
            box-shadow: 0px 0px 30px blue; 
        }
         
        
        .imagediv{
            position: absolute;
            width:195px ;
            height:195px ;
            border-bottom: 3px solid orange ;
        }
        .productimg{
            position: absolute;
            width:100% ;
            height:100% ;


        }
        .titlediv{
            position: relative;
            top:200px;
            padding: 5px;
            width:100% ;
        }
        h4{
            position: absolute;
            
        }
        .buttons_style{
            display: none;
        }
        .formdiv{
            position: absolute;
            top: 30px;
            left: 30px;
            width: 95%;
            height: 95%;
        }
        .h4class{
            font-size: 13px;
            font-weight: bold;
        }
        
    </style>
</head>
<body>
    
</body>
</html>

<?php
$connection = mysqli_connect('localhost', 'root', '', 'woodmastery');
// Set the number of results per page
$resultsPerPage = 3;

// Get the current page from the URL, default to 1 if not set
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Calculate the starting point for the results to fetch from the database
$startFrom = ($page - 1) * $resultsPerPage;

// Your search query (you may need to modify this based on your actual search implementation)
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Fetch data from the database based on the search term and pagination
$query = "SELECT Product_id, Images, Title FROM product WHERE Catagory =  '$searchTerm' AND  Unlisted_or_Deleted = 1 ORDER BY time_date DESC LIMIT {$startFrom}, {$resultsPerPage}";
$result = mysqli_query($connection, $query);

$i="";
// Display the search results
while ($row = mysqli_fetch_assoc($result)) {
    // Display your results here
    $i++;

    $div = "<div class='canteinerdiv' >";
    $div .= "
    
    <form action='leval3.php' method='GET'>
        
        <input type='hidden' name='Product_id' value='{$row['Product_id']}'>
        <input type='hidden' name='Images' value='{$row['Images']}'>
        <label class='canteinerlabel' for='button$i' >
        <div class='imagediv'><img src='{$row['Images']}' class='productimg'></div>
        <div class='titlediv'><h4 class='h4class'>{$row['Title']}</h4></div>
        </label>
        <input type='submit' name='submit' class='buttons_style' id='button$i' ' >
        
    </form>
    
    
    
    ";
    
    $div .= "</div>";
    echo $div;
}

// Calculate the total number of pages
$totalPagesQuery = "SELECT COUNT(Product_id) AS total_rows FROM product WHERE Catagory =  '$searchTerm' AND  Unlisted_or_Deleted = 1 ORDER BY time_date DESC ";
$totalPagesResult = mysqli_query($connection, $totalPagesQuery);
$totalRows = mysqli_fetch_assoc($totalPagesResult)['total_rows'];
$totalPages = ceil($totalRows / $resultsPerPage);



$lastpage_no = ceil($totalRows/$resultsPerPage);
                    if ($page >= $lastpage_no) {
                      $next = "<a id='next'>NEXT</a>";
                  } else {
                      $next_page_no = $page + 1;
                      $next = "<a id='next' href=\"ex2.php?search=Chair&page={$next_page_no}\">NEXT</a>";
                  }
                  
                  if ($page <= 1) {
                      $previs = "<a id='previous'>PREVIOUS</a>";
                  } else {
                      $prev_page_no = $page - 1;
                      $previs = "<a id='previous' href=\"ex2.php?search=Chair&page={$prev_page_no}\">PREVIOUS</a>";
                  }

echo "<div class='npbutton'>";
echo $previs . '&nbsp;&nbsp;&nbsp;&nbsp; ' . ' ' . $page . '&nbsp;&nbsp;&nbsp;&nbsp; ' . ' ' . $next;
echo "</div>";
// Display pagination links


// Close the database connection
mysqli_close($connection);
?>
