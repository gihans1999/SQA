<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Form</title>
</head>
<body>
    <form action="ex2.php" method="get">
        <label for="searchTerm">Search:</label>
        <input type="radio" id="searchTerm" name="search" value="Chair">
        <input type="submit">
    </form>
</body>
</html>
