



<?php

require 'products.php'; 

use PHPUnit\Framework\TestCase;

class productsTest extends TestCase
{
    public function testproductsFunction() {
        $result = productsFunction('expected_value'); 
        $this->assertEquals('expected output', $result); 

        $result = productsFunction('unexpected_value'); 
        $this->assertEquals('unexpected output', $result); 
    }
}
?>


