<?php
$serverName="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="woodmastery";

$conn = mysqli_connect($serverName,$dbUsername,$dbPassword,$dbName);

//Check the connection is built or not (For debuging)

if($conn){
   // echo "Connection OK";
}
else{
    echo "Connection failed" .mysqli.error();
}

//Below ['text'] should be from login.php/Registration form name= ""//
$name= $_POST['name'];
$email= $_POST['email'];
$pwd= $_POST['pwd'];
$confirmpass= $_POST['confirmpass'];

$query= "INSERT INTO users VALUES('','$name','$email','$pwd','$confirmpass','','') ";
$data= mysqli_query($conn,$query);
if($data){
    //echo "Data is send" ;
    header("Location:login.php") ;
}
else{
    echo "Data is not send" ;
}


?>