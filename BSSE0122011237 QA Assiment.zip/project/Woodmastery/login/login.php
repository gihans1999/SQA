<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="login.css">
    <!-- Below CSS link(For icons of labels)from this web side-: https://boxicons.com/?query=enve -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

</head>
<body>

    <!--Login Form-->
    <div class="login-section">
        <div class="formbox login" id="loginForm">
            <form action="loginCheck.php" method="POST">

                <h2> Login </h2>
                <div class="input-box">
                    <span class="icon">
                        <i class='bx bxs-envelope'> </i> <!--from boxicons.com-->
                    </span>
                    <input type="text" id="email" name="email" required>
                    <label> Email </label>
                </div>

                <div class="input-box">
                    <span class="icon">
                       <i class='bx bxs-lock-alt'> </i> <!--From boxicons.com-->
                    </span>
                    <input type="password" id="password" name="pwd" required>
                      <label> Password </label>
                </div>

                <div class="remember-password">
                    <label> <Input type="checkbox"> Remember me </label>
                    <a href="forgot_password.html"> Forget Password </a>
                </div>

                <input type="submit" class="btn" value= "Login"  > 
                  
                <div class="create-account">
                    <p> Don't have an account? <a href="#" class="register-link">Register</a> </p>
                </div>
            </form>
           
        </div>
       <!--End of Login form-->



        <!--Register form-->
        <div class="formbox register" id="registerForm" >
            <form action= "connection.php" method="POST">
                <h2> Register </h2>
                <div class="input-box">
                    <span class="icon">
                      <i class='bx bxs-user'></i> <!--from boxicons.com-->
                    </span>
                    <input type="text" id="name" name="name" required>
                    <label> Name </label>
                </div>
        
                <div class="input-box">
                    <span class="icon">
                      <i class='bx bxs-envelope'> </i> <!--from boxicons.com-->
                    </span>
                    <input type="email" id="email" name="email" required>
                    <label> Email </label>
                </div>
        
                <div class="input-box">
                    <span class="icon">
                       <i class='bx bxs-lock-alt'> </i> <!--From boxicons.com-->
                    </span> 
                    <input type="password" id="password" name= "pwd" required>
                    <label> Password </label>
                </div>
                
                <div class="input-box">
                    <span class="icon">
                      <i class='bx bxs-lock-alt'> </i> <!--From boxicons.com-->
                    </span>
                    <input type="password" id="confirmpassword" name= "confirmpass" required>
                    <label> Confirm Password </label>
                </div>
                
                <div class="condition-checker">
                    <Input type="checkbox" id="termsCheckbox"required>
                    <label for="termsCheckbox">I accept the <a href="conditionForm.php" id="termsLink"> Terms & Conditions.</a> </label>
                </div>
        
                <input type="submit" class="btn" value= "Register" >

                <div class="create-account">
                    <p>Already have an account? <a href="#" class="login-link"> Login </a> </p>
                </div> 
                
            </form>
           
        </div>
    </div>
   <!--End of Register form-->

   <script src="login.js"> </script>
   <script src="validation.js"> </script>
   



  
</body>
</html>










