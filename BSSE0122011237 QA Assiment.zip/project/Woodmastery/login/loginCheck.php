<?php
$serverName="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="woodmastery";

$check= mysqli_connect($serverName,$dbUsername,$dbPassword,$dbName);

//Check the connection is built or not (For debuging)
if($check){
    //echo "Connection is OK" ;
}
else{
    echo "Connection is failed";
}

//Below ['text'] should be from login.php/Register form name= ""//
$email= $_POST['email'];
$pwd= $_POST['pwd'];

$data= "SELECT * FROM users  WHERE email='$email' && pwd='$pwd' ";
$execute= mysqli_query($check,$data);
$count= mysqli_num_rows($execute);
if($count>=1){
    //echo "You can login" ;
    header("Location:../profile.php");   
}
else{
    echo '<script>alert("Invalid login")</script>' ;
      
}







?>