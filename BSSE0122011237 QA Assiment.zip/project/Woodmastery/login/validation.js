// Forms validations //
const loginForm = document.querySelector('.login form');
const registerForm = document.querySelector('.register form');

// Add event listener for login submission
loginForm.addEventListener('submit', function (event) {
    if (!validateEmail(loginForm.email.value) || !validatePassword(loginForm.password.value)) {
        event.preventDefault();
    }
});

// Add event listener for register submission
registerForm.addEventListener('submit', function (event) {
    if (!validateName(registerForm.name.value) || !validateEmail(registerForm.email.value) || 
        !validatePassword(registerForm.password.value) || !validateConfirmPassword(registerForm.confirmpassword.value)) {
        event.preventDefault();
    }
});


// Validation functions
function validateName(name) {
  const invalidChars = /[0-9!@#$%^&*()+\-/]/;
  
  if (invalidChars.test(name)) {
      alert('Please enter a valid name without numbers or special characters.');
      return false;
  }
  
  return true;
}

function validateEmail(email) {
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    if (!email.match(emailPattern)) {
        return false;
    }
    return true;
}

function validatePassword(password) {
    if (password.length < 8) {
        alert('Password must be at least 8 characters long.');
        return false;
    }
    return true;
}

function validateConfirmPassword(confirmPassword) {
    const password = registerForm.password.value;
    if (confirmPassword !== password) {
        alert('Passwords do not match.');
        return false;
    }
    return true;
}
